import React from 'react'

function NoAccess() {
  return (
    <div>
    <h2>No Access</h2>
</div>
  )
}

export default NoAccess
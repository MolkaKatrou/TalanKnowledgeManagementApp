import React from 'react'
import { Container, makeStyles, Typography } from "@material-ui/core"
import { Bookmark, Home } from '@material-ui/icons'
import Bookmarks from '@mui/icons-material/Bookmarks';
import Drafts from '@mui/icons-material/Drafts';
import { Link } from "react-router-dom";
import AdminPanel from '@mui/icons-material/AdminPanelSettings';
const useStyles = makeStyles((theme) => ({
  container: {
    height: "100vh",
    backgroundColor: '#8084ac',
    paddingTop: theme.spacing(10),
    position: "sticky",
    top: 0,
    [theme.breakpoints.up("sm")]: {
      backgroundColor: '#8084ac',
      color: "#555",
      border: "1px solid #ece7e7",
    },
  },
  item: {
    display: "flex",
    alignItems: "center",
    color: 'black',
    cursor: "pointer",
    marginBottom: theme.spacing(4),
    [theme.breakpoints.up("sm")]: {
      marginBottom: theme.spacing(3),
      cursor: "pointer",
    },
  },
  icon: {
    marginRight: theme.spacing(1),
    [theme.breakpoints.up("sm")]: {
      fontSize: "21px",
    },
  },
  text: {
    fontWeight: 500,
    [theme.breakpoints.down("sm")]: {
      display: "none",
    },
  },
}));


const Sidebar = ({ user }) => {
  const classes = useStyles()
  return (
    <Container className={classes.container} >
      <div className={classes.item}>
        <Home className={classes.icon} />
        <Typography className={classes.text}>
          Home
        </Typography>
      </div>
      <div className={classes.item}>
        <Bookmark className={classes.icon} />
        <Typography className={classes.text}>
          Bookmarks
        </Typography>
      </div>
      <div className={classes.item}>
        <Drafts className={classes.icon} />
        <Typography className={classes.text}>
          Drafts
        </Typography>
      </div>
      {user.role === "ADMIN" ? (
      <div className={classes.item}>
        <AdminPanel className={classes.icon} />
        <Typography className={classes.text}>
             
                <Link aria-current="page" to="/admin" style={{ textDecoration: 'none', color:'black' }}>
                  Admin Dashboard
                </Link>
        </Typography>
      </div>
      ) : (
        ""
      )}

    </Container>
  )
}

export default Sidebar